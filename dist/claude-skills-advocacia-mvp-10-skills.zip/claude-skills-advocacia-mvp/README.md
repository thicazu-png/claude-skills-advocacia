# Claude Skills Advocacia MVP

Pacote inicial de Agent Skills para produção de conteúdo jurídico digital por advogados brasileiros, com foco em estratégia editorial, conformidade com ética/publicidade profissional, revisão de precisão jurídica e reaproveitamento multicanal.

## Skills incluídas

1. `juridico-content-strategy`
   - Planeja calendário editorial, pilares de conteúdo, público-alvo e formato por canal.

2. `oab-compliance-review`
   - Revisa conteúdos jurídicos digitais para reduzir riscos de mercantilização, captação indevida, promessa de resultado e linguagem incompatível com sobriedade profissional.

3. `legal-accuracy-review`
   - Verifica precisão jurídica, qualidade das fontes, limites da tese e riscos de extrapolação.

4. `multichannel-repurposing`
   - Adapta um conteúdo jurídico-base para LinkedIn, newsletter, blog, roteiro de vídeo curto e carrossel.

5. `labor-law-business-content`
   - Produz conteúdo trabalhista consultivo e contencioso voltado a empresas, RH, compliance e jurídico interno.

6. `digital-law-lgpd-ai-content`
   - Produz conteúdo sobre direito digital, LGPD, IA, propriedade intelectual, governança de dados e tecnologia aplicada.

7. `case-law-to-content`
   - Transforma acórdãos, ementas, decisões, notícias jurídicas e teses jurisprudenciais em conteúdo digital com limites, contexto e cautela técnica.

8. `visual-law-legal-design`
   - Converte conteúdo jurídico em quadros, checklists visuais, fluxos decisórios, mapas mentais, carrosséis e materiais de visual law com clareza e sobriedade.

9. `business-tech-contract-review`
   - Revisa contratos empresariais e tecnológicos, identificando cláusulas críticas, riscos, pontos de negociação e matriz executiva de revisão.

10. `legal-ops-ai-management`
   - Estrutura rotinas internas de escritório jurídico com IA, incluindo triagem, produtividade, padronização de entregas, controle de qualidade e gestão de conhecimento.

## Fluxo recomendado

1. Use `juridico-content-strategy` para definir pauta, público, canal e objetivo.
2. Produza o rascunho com `labor-law-business-content`, `digital-law-lgpd-ai-content`, `case-law-to-content` ou com seu prompt usual.
3. Use `legal-accuracy-review` para checar precisão, fontes e limites.
4. Use `oab-compliance-review` para revisar ética/publicidade antes de publicar.
5. Use `multichannel-repurposing` para adaptar o conteúdo aos canais escolhidos.
6. Use `visual-law-legal-design` quando quiser transformar o conteúdo em peça visual, carrossel, mapa, quadro comparativo ou fluxo decisório.
7. Use `business-tech-contract-review` para revisar contratos, termos, propostas, SaaS, tecnologia, prestação de serviços, confidencialidade, dados e propriedade intelectual.
8. Use `legal-ops-ai-management` para organizar fluxos internos, triagem, checklists operacionais, padrões de entrega, base de conhecimento e governança de uso de IA.

## Observação

Este pacote não substitui revisão profissional. Todo conteúdo jurídico gerado por IA deve ser conferido por advogado responsável antes de publicação, especialmente quando envolver jurisprudência, direitos individuais, dados pessoais, publicidade profissional ou tese controvertida.
